import java.util.*;

class Equipe {
private String nome;
private List&lt;Combatente&gt; membros = new ArrayList&lt;&gt;();

public Equipe(String nome) {
this.nome = nome;
}

public String getNome() { return nome; }
public List&lt;Combatente&gt; getMembros() { return Collections.unmodifiableList(membros); }

public void adicionarCombatente(Combatente c) {
if (c != null) membros.add(c);
}

public void removerCombatente(Combatente c) {
membros.remove(c);
}

public int calcularForcaTotal() {
int soma = 0;
for (Combatente c : membros) {
if (c.estaVivo()) soma += c.getAtaque() + c.getDefesa() + c.getVida()/5;
}
return soma;
}

public boolean temVivos() {
for (Combatente c : membros) if (c.estaVivo()) return true;
return false;
}

@Override
public String toString() {
StringBuilder sb = new StringBuilder();
sb.append(&quot;Equipe: &quot;).append(nome).append(&quot;\n&quot;);
for (Combatente c : membros) {
sb.append(&quot; - &quot;).append(c).append(&quot;\n&quot;);
}
return sb.toString();
}
}