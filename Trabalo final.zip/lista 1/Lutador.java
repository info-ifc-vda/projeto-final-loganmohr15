import java.util.*;

/* Lutador Corpo-a-corpo */
class Lutador extends Combatente {
public Lutador(String nome, Mitologia m, int nivel) {
super(nome, m, 80 + nivel * 5, 18 + nivel * 2, 8 + nivel, nivel);
}

@Override
public void atacar(Combatente alvo, Random rnd) {
// golpe forte corpo-a-corpo com chance de crítico
int base = getAtaque();
boolean crit = rnd.nextInt(100) &lt; 15; // 15% crítico
int dano = base + (crit ? base/2 : 0);
System.out.printf(&quot;&gt; %s desfere um golpe (crit: %b) em %s.\n&quot;, getNome(), crit,
alvo.getNome());
int danoFinal = alvo.defender(dano, rnd);
System.out.printf(&quot;Dano causado: %d\n&quot;, danoFinal);
}

@Override
public int defender(int danoRecebido, Random rnd) {

int mitigado = Math.max(0, danoRecebido - getDefesa());
aplicarDano(mitigado);
return mitigado;
}

@Override
public String descricao() {
return &quot;Lutador corpo-a-corpo: alto dano físico e chance de crítico.&quot;;
}
}

/* Cavaleiro: defesa alta, golpe moderado */
class Cavaleiro extends Combatente {
public Cavaleiro(String nome, Mitologia m, int nivel) {
super(nome, m, 100 + nivel * 6, 15 + nivel*2, 14 + nivel*2, nivel);
}

@Override
public void atacar(Combatente alvo, Random rnd) {
// ataque mais estável
int dano = getAtaque();
System.out.printf(&quot;&gt; %s investe contra %s.\n&quot;, getNome(), alvo.getNome());
int danoFinal = alvo.defender(dano, rnd);
System.out.printf(&quot;Dano causado: %d\n&quot;, danoFinal);
}

@Override
public int defender(int danoRecebido, Random rnd) {
// chance de bloquear parcialmente
boolean bloqueio = rnd.nextInt(100) &lt; 25; // 25% reduz dano pela metade
int dano = danoRecebido;

if (bloqueio) {
dano = danoRecebido / 2;
System.out.printf(&quot;&gt; %s executou um bloqueio!\n&quot;, getNome());
}
int mitigado = Math.max(0, dano - getDefesa());
aplicarDano(mitigado);
return mitigado;
}

@Override
public String descricao() {
return &quot;Cavaleiro: grande resistência e defesa, bom para segurar linha de frente.&quot;;
}
}

/* Atacante à Distância (arqueiro/lanceiro) */
class AtacanteDistancia extends Combatente {
public AtacanteDistancia(String nome, Mitologia m, int nivel) {
super(nome, m, 70 + nivel * 4, 16 + nivel*2, 6 + nivel, nivel);
}

@Override
public void atacar(Combatente alvo, Random rnd) {
// dano baseado em ataque, chance de acerto crítico aumentado vs alvos desprevenidos
int dano = getAtaque();
if (rnd.nextInt(100) &lt; 20) { // 20% headshot
dano += getAtaque() / 2;
System.out.printf(&quot;&gt; %s acerta um tiro preciso em %s!\n&quot;, getNome(), alvo.getNome());
} else {
System.out.printf(&quot;&gt; %s atira em %s.\n&quot;, getNome(), alvo.getNome());
}

int danoFinal = alvo.defender(dano, rnd);
System.out.printf(&quot;Dano causado: %d\n&quot;, danoFinal);
}

@Override
public int defender(int danoRecebido, Random rnd) {
// frágil, menos defesa
int mitigado = Math.max(0, danoRecebido - getDefesa());
aplicarDano(mitigado);
return mitigado;
}

@Override
public String descricao() {
return &quot;Atacante à distância: bom dano por ataque único, porém frágil.&quot;;
}
}

/* Combatente Estratégico (suporta efeitos) */
class Estrategista extends Combatente {
public Estrategista(String nome, Mitologia m, int nivel) {
super(nome, m, 75 + nivel * 4, 12 + nivel*2, 10 + nivel, nivel);
}

@Override
public void atacar(Combatente alvo, Random rnd) {
// aplica dano e pequeno efeito: reduz defesa do alvo temporariamente
int dano = getAtaque();
System.out.printf(&quot;&gt; %s executa uma manobra estratégica contra %s.\n&quot;, getNome(),
alvo.getNome());
int danoFinal = alvo.defender(dano, rnd);

// efeito: chance de reduzir defesa
if (rnd.nextInt(100) &lt; 30) {
int reduction = 2 + getNivel()/2;
alvo.setDefesa(Math.max(0, alvo.getDefesa() - reduction));
System.out.printf(&quot;&gt; %s teve sua defesa reduzida em %d.\n&quot;, alvo.getNome(), reduction);
}
System.out.printf(&quot;Dano causado: %d\n&quot;, danoFinal);
}

@Override
public int defender(int danoRecebido, Random rnd) {
// defende com tática: reduz dano com parte da defesa
int mitigado = Math.max(0, danoRecebido - (getDefesa()+2));
aplicarDano(mitigado);
return mitigado;
}

@Override
public String descricao() {
return &quot;Combatente estratégico: manipula combate, pode enfraquecer o inimigo.&quot;;
}
}

/* Robô de Combate (tem atributos especiais, mais &quot;tecnológico&quot;) */
class Robo extends Combatente {
public Robo(String nome, Mitologia m, int nivel) {
super(nome, m, 90 + nivel*5, 20 + nivel*2, 10 + nivel, nivel);
}

@Override
public void atacar(Combatente alvo, Random rnd) {

int dano = getAtaque();
// Robo causa dano e pode auto-regenerar uma pequena quantidade
System.out.printf(&quot;&gt; %s (Robo) dispara suas armas em %s.\n&quot;, getNome(), alvo.getNome());
int danoFinal = alvo.defender(dano, rnd);
if (rnd.nextInt(100) &lt; 20) {
// regenera
int cura = 5 + getNivel();
setVida(getVida() + cura);
System.out.printf(&quot;&gt; %s autorregenera %d de vida.\n&quot;, getNome(), cura);
}
System.out.printf(&quot;Dano causado: %d\n&quot;, danoFinal);
}

@Override
public int defender(int danoRecebido, Random rnd) {
// blindagem: reduz dano consideravelmente
int mitigado = Math.max(0, danoRecebido - (getDefesa() + 3));
aplicarDano(mitigado);
return mitigado;
}

@Override
public String descricao() {
return &quot;Robô: alta potência e auto-regeneração ocasional.&quot;;
}
}

/* Mago: dano por habilidade especial (magia) */
class Mago extends Combatente {
public Mago(String nome, Mitologia m, int nivel) {
super(nome, m, 65 + nivel*3, 22 + nivel*3, 5 + nivel, nivel);

}

@Override
public void atacar(Combatente alvo, Random rnd) {
// magia: dano variável com chance de efeito especial (queimar/queimar causa dano extra)
int dano = getAtaque() + rnd.nextInt(6);
System.out.printf(&quot;&gt; %s conjura uma magia contra %s.\n&quot;, getNome(), alvo.getNome());
int danoFinal = alvo.defender(dano, rnd);
if (rnd.nextInt(100) &lt; 25) {
int burn = 3 + getNivel();
alvo.aplicarDano(burn);
System.out.printf(&quot;&gt; Efeito mágico: %s sofre %d de dano mágico adicional.\n&quot;,
alvo.getNome(), burn);
}
System.out.printf(&quot;Dano causado: %d\n&quot;, danoFinal);
}

@Override
public int defender(int danoRecebido, Random rnd) {
// mago tenta usar escudo mágico (chance)
if (rnd.nextInt(100) &lt; 20) {
System.out.printf(&quot;&gt; %s conjurou um escudo e reduziu parte do dano!\n&quot;, getNome());
danoRecebido = danoRecebido / 2;
}
int mitigado = Math.max(0, danoRecebido - getDefesa());
aplicarDano(mitigado);
return mitigado;
}

@Override
public String descricao() {

return &quot;Mago: alto dano mágico, porém frágil fisicamente.&quot;;
}
}