import java.util.*;

abstract class Item {
private String nome;
private String tipo;

public Item(String nome, String tipo) {
this.nome = nome;
this.tipo = tipo;
}

public String getNome() { return nome; }
public String getTipo() { return tipo; }

public abstract void efeito(Combatente alvo);
}

/* Consumível que cura */
class Poção extends Item {
private int cura;

public Poção(String nome, int cura) {
super(nome, &quot;Consumível&quot;);
this.cura = cura;
}

@Override
public void efeito(Combatente alvo) {
int novaVida = alvo.getVida() + cura;
alvo.setVida(novaVida);
System.out.printf(&quot;&gt; %s recuperou %d de vida.\n&quot;, alvo.getNome(), cura);
}
}

/* Arma que aumenta ataque temporariamente (aplicado permanentemente para simplicidade) */
class Arma extends Item {
private int bonusAtk;

public Arma(String nome, int bonus) {
super(nome, &quot;Arma&quot;);
this.bonusAtk = bonus;
}

@Override
public void efeito(Combatente alvo) {
alvo.setAtaque(alvo.getAtaque() + bonusAtk);
System.out.printf(&quot;&gt; %s recebeu +%d de ataque.\n&quot;, alvo.getNome(), bonusAtk);
}
}

/* Armadura que aumenta defesa */
class Armadura extends Item {
private int bonusDef;

public Armadura(String nome, int bonus) {
super(nome, &quot;Armadura&quot;);
this.bonusDef = bonus;

}

@Override
public void efeito(Combatente alvo) {
alvo.setDefesa(alvo.getDefesa() + bonusDef);
System.out.printf(&quot;&gt; %s recebeu +%d de defesa.\n&quot;, alvo.getNome(), bonusDef);
}
}