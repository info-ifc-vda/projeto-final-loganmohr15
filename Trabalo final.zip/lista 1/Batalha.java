import java.util.*;

class Batalha {
private Equipe equipeA;
private Equipe equipeB;
private Random rnd = new Random();

private boolean usuarioControla; // se true, usuário escolhe ações, senão simula

public Batalha(Equipe a, Equipe b, boolean usuarioControla) {
this.equipeA = a;
this.equipeB = b;
this.usuarioControla = usuarioControla;
}

public void iniciar() {
System.out.println(&quot;=== INÍCIO DA BATALHA ===&quot;);
System.out.println(equipeA);
System.out.println(equipeB);
int turno = 1;
while (!verificarFim() &amp;&amp; turno &lt;= 200) {
System.out.println(&quot;\n=== TURNO &quot; + turno + &quot; ===&quot;);
executarTurno();
turno++;
}
System.out.println(&quot;\n=== FIM DA BATALHA ===&quot;);
if (equipeA.temVivos() &amp;&amp; !equipeB.temVivos()) System.out.println(&quot;Equipe &quot; +
equipeA.getNome() + &quot; venceu!&quot;);
else if (equipeB.temVivos() &amp;&amp; !equipeA.temVivos()) System.out.println(&quot;Equipe &quot; +
equipeB.getNome() + &quot; venceu!&quot;);
else System.out.println(&quot;Empate ou limite de turnos atingido.&quot;);
}

private Combatente escolherAtacante(Equipe eq) {
List&lt;Combatente&gt; vivos = new ArrayList&lt;&gt;();
for (Combatente c : eq.getMembros()) if (c.estaVivo()) vivos.add(c);
if (vivos.isEmpty()) return null;
return vivos.get(rnd.nextInt(vivos.size()));
}

private Combatente escolherAlvo(Equipe inimigos) {
List&lt;Combatente&gt; vivos = new ArrayList&lt;&gt;();
for (Combatente c : inimigos.getMembros()) if (c.estaVivo()) vivos.add(c);
if (vivos.isEmpty()) return null;
return vivos.get(rnd.nextInt(vivos.size()));
}

public void executarTurno() {
// ordem simples: equipe A atua, depois equipe B
turnoPorEquipe(equipeA, equipeB);
if (verificarFim()) return;
turnoPorEquipe(equipeB, equipeA);
}

private void turnoPorEquipe(Equipe atacanteEq, Equipe defensorEq) {
Combatente atacante = escolherAtacante(atacanteEq);
if (atacante == null) return;
if (!usuarioControla) {
// automático: escolhe alvo e ataca
Combatente alvo = escolherAlvo(defensorEq);
if (alvo == null) return;
System.out.printf(&quot;&gt; %s ataca %s\n&quot;, atacante.getNome(), alvo.getNome());
atacante.atacar(alvo, rnd);
relatarEstado(alvo);
} else {
// modo usuário controla: permite escolher ação entre atacar, usar item ou pular
Scanner sc = new Scanner(System.in);
System.out.println(&quot;Atacante: &quot; + atacante);
System.out.println(&quot;Ações disponíveis:&quot;);
System.out.println(&quot;1) Atacar&quot;);

System.out.println(&quot;2) Usar item&quot;);
System.out.println(&quot;3) Defender (pular e ganhar +defesa temporária)&quot;);
System.out.print(&quot;Escolha ação (número): &quot;);
String escolha = sc.nextLine();
switch (escolha) {
case &quot;1&quot;: {
// escolher alvo
System.out.println(&quot;Escolha alvo entre inimigos vivos:&quot;);
List&lt;Combatente&gt; vivos = new ArrayList&lt;&gt;();
for (Combatente c : defensorEq.getMembros()) if (c.estaVivo()) vivos.add(c);
for (int i = 0; i &lt; vivos.size(); i++) {
System.out.printf(&quot;%d) %s\n&quot;, i+1, vivos.get(i));
}
System.out.print(&quot;Alvo (número): &quot;);
try {
int idx = Integer.parseInt(sc.nextLine()) - 1;
if (idx &gt;= 0 &amp;&amp; idx &lt; vivos.size()) {
Combatente alvo = vivos.get(idx);
atacante.atacar(alvo, rnd);
relatarEstado(alvo);
} else System.out.println(&quot;Alvo inválido.&quot;);
} catch (NumberFormatException e) { System.out.println(&quot;Entrada inválida.&quot;); }
break;
}
case &quot;2&quot;: {
// usar item
List&lt;Item&gt; itens = atacante.getInventario();
if (itens.isEmpty()) {
System.out.println(&quot;&gt; Sem itens.&quot;);
break;
}

System.out.println(&quot;Itens:&quot;);
for (int i = 0; i &lt; itens.size(); i++) {
System.out.printf(&quot;%d) %s (%s)\n&quot;, i+1, itens.get(i).getNome(), itens.get(i).getTipo());
}
System.out.print(&quot;Escolha item (número): &quot;);
try {
int itIdx = Integer.parseInt(sc.nextLine()) - 1;
if (itIdx &gt;= 0 &amp;&amp; itIdx &lt; itens.size()) {
Item it = itens.get(itIdx);
// escolher alvo do item (pode ser aliado ou inimigo dependendo do tipo)
System.out.println(&quot;Escolha alvo (1) Auto (2) Aliado (3) Inimigo:&quot;);
String targetChoice = sc.nextLine();
if (&quot;1&quot;.equals(targetChoice)) {
atacante.usarItem(itIdx, atacante);
} else if (&quot;2&quot;.equals(targetChoice)) {
List&lt;Combatente&gt; aliados = new ArrayList&lt;&gt;();
for (Combatente c : atacanteEq.getMembros()) if (c.estaVivo()) aliados.add(c);
for (int i = 0; i &lt; aliados.size(); i++) System.out.printf(&quot;%d) %s\n&quot;, i+1,
aliados.get(i));
System.out.print(&quot;Escolha aliado (num): &quot;);
int aIdx = Integer.parseInt(sc.nextLine()) - 1;
if (aIdx &gt;= 0 &amp;&amp; aIdx &lt; aliados.size()) {
atacante.usarItem(itIdx, aliados.get(aIdx));
} else System.out.println(&quot;Alvo inválido.&quot;);
} else if (&quot;3&quot;.equals(targetChoice)) {
List&lt;Combatente&gt; inimigos = new ArrayList&lt;&gt;();
for (Combatente c : defensorEq.getMembros()) if (c.estaVivo()) inimigos.add(c);
for (int i = 0; i &lt; inimigos.size(); i++) System.out.printf(&quot;%d) %s\n&quot;, i+1,
inimigos.get(i));
System.out.print(&quot;Escolha inimigo (num): &quot;);
int iIdx = Integer.parseInt(sc.nextLine()) - 1;
if (iIdx &gt;= 0 &amp;&amp; iIdx &lt; inimigos.size()) {

atacante.usarItem(itIdx, inimigos.get(iIdx));
} else System.out.println(&quot;Alvo inválido.&quot;);
} else System.out.println(&quot;Opção inválida.&quot;);
} else System.out.println(&quot;Item inválido.&quot;);
} catch (Exception e) { System.out.println(&quot;Entrada inválida.&quot;); }
break;
}
case &quot;3&quot;: {
// defender: ganha defesa temporária (aplicaremos como aumento permanente pequeno
por simplicidade)
int bonus = 3 + atacante.getNivel();
atacante.setDefesa(atacante.getDefesa() + bonus);
System.out.printf(&quot;&gt; %s entrou em postura defensiva e ganhou +%d de defesa.\n&quot;,
atacante.getNome(), bonus);
break;
}
default:
System.out.println(&quot;Ação inválida — turno perdido.&quot;);
}
}
}

private void relatarEstado(Combatente alvo) {
System.out.printf(&quot;%s agora possui %d de vida.\n&quot;, alvo.getNome(), alvo.getVida());
if (!alvo.estaVivo()) System.out.printf(&quot;&gt; %s foi eliminado!\n&quot;, alvo.getNome());
}

public boolean verificarFim() {
return !equipeA.temVivos() || !equipeB.temVivos();
}
}