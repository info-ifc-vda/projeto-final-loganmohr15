import java.util.*;

CLASSE PRINCIPAL (main)
------------------------------*/
public class MythologyBattleGame {
private static Scanner sc = new Scanner(System.in);
private static Random rnd = new Random();

public static void main(String[] args) {
System.out.println(&quot;=== Mythology Battle Game ===&quot;);
System.out.println(&quot;Tema: Mitologias - Grega, Nórdica, Egípcia, Celta&quot;);
System.out.println();

// Menu inicial: criar equipes ou usar predefinidas
System.out.println(&quot;1) Usar equipes pré-definidas&quot;);
System.out.println(&quot;2) Criar equipes manualmente&quot;);
System.out.print(&quot;Escolha: &quot;);
String escolha = sc.nextLine();
Equipe e1 = null, e2 = null;

if (&quot;1&quot;.equals(escolha)) {
e1 = timePreDefinidoA();
e2 = timePreDefinidoB();
} else {
System.out.print(&quot;Nome da Equipe A: &quot;);
String nomeA = sc.nextLine();
e1 = new Equipe(nomeA);
criarTimeInterativo(e1);
System.out.print(&quot;Nome da Equipe B: &quot;);
String nomeB = sc.nextLine();
e2 = new Equipe(nomeB);
criarTimeInterativo(e2);

}

System.out.println(&quot;\nEscolha modo de batalha:&quot;);
System.out.println(&quot;1) Modo Automático (simulação)&quot;);
System.out.println(&quot;2) Modo Manual (você escolhe ações durante a batalha)&quot;);
System.out.print(&quot;Escolha: &quot;);
String modo = sc.nextLine();
boolean usuarioControla = &quot;2&quot;.equals(modo);

Batalha batalha = new Batalha(e1, e2, usuarioControla);
batalha.iniciar();

// fim
System.out.println(&quot;\nObrigado por jogar!&quot;);
}

// Métodos auxiliares para criar times pré-definidos
private static Equipe timePreDefinidoA() {
Equipe e = new Equipe(&quot;Os Olímpicos&quot;);
Combatente a = new Lutador(&quot;Hoplita Grego&quot;, Mitologia.GREGA, 3);
Combatente b = new Mago(&quot;Oráculo Místico&quot;, Mitologia.GREGA, 2);
Combatente c = new AtacanteDistancia(&quot;Arqueiro Esparci&quot;, Mitologia.GREGA, 2);
a.adicionarItem(new Poção(&quot;Poção de Ambrosia&quot;, 20));
b.adicionarItem(new Arma(&quot;Cajado de Zeus&quot;, 3));
e.adicionarCombatente(a);
e.adicionarCombatente(b);
e.adicionarCombatente(c);
return e;
}

private static Equipe timePreDefinidoB() {

Equipe e = new Equipe(&quot;Invasores do Norte&quot;);
Combatente a = new Cavaleiro(&quot;Berserker&quot;, Mitologia.NORDICA, 3);
Combatente b = new Robo(&quot;Rúnico Autômato&quot;, Mitologia.NORDICA, 2);
Combatente c = new Estrategista(&quot;Skald Estrategista&quot;, Mitologia.NORDICA, 2);
a.adicionarItem(new Armadura(&quot;Peitoral de Aço&quot;, 4));
e.adicionarCombatente(a);
e.adicionarCombatente(b);
e.adicionarCombatente(c);
return e;
}

// Criar time interativo
private static void criarTimeInterativo(Equipe e) {
System.out.println(&quot;Vamos adicionar membros para &quot; + e.getNome());
boolean continuar = true;
while (continuar) {
System.out.print(&quot;Nome do combatente: &quot;);
String nome = sc.nextLine();
Mitologia m = escolherMitologia();
System.out.println(&quot;Tipos disponíveis: 1)Lutador 2)Cavaleiro 3)Distância 4)Estratégista 5)Robo
6)Mago&quot;);
System.out.print(&quot;Escolha tipo (número): &quot;);
String t = sc.nextLine();
int nivel = 1;
System.out.print(&quot;Nível (1-5): &quot;);
try { nivel = Integer.parseInt(sc.nextLine()); } catch (Exception ex) { nivel = 1; }
Combatente c = criarCombatentePorTipo(t, nome, m, nivel);
if (c != null) {
// adicionar 50% chance de item inicial
if (rnd.nextBoolean()) c.adicionarItem(new Poção(&quot;Poção Curativa&quot;, 15));
e.adicionarCombatente(c);

System.out.println(&quot;Adicionado: &quot; + c);
} else {
System.out.println(&quot;Tipo inválido - não adicionado.&quot;);
}
System.out.print(&quot;Adicionar outro? (s/n): &quot;);
String resp = sc.nextLine();
if (!resp.toLowerCase().startsWith(&quot;s&quot;)) continuar = false;
}
}

private static Mitologia escolherMitologia() {
System.out.println(&quot;Mitologias: 1)Grega 2)Nórdica 3)Egípcia 4)Celta&quot;);
System.out.print(&quot;Escolha (número): &quot;);
String m = sc.nextLine();
switch (m) {
case &quot;1&quot;: return Mitologia.GREGA;
case &quot;2&quot;: return Mitologia.NORDICA;
case &quot;3&quot;: return Mitologia.EGIPCIA;
case &quot;4&quot;: return Mitologia.CELTA;
default: return Mitologia.GREGA;
}
}

private static Combatente criarCombatentePorTipo(String tipo, String nome, Mitologia m, int
nivel) {
switch (tipo) {
case &quot;1&quot;: return new Lutador(nome, m, nivel);
case &quot;2&quot;: return new Cavaleiro(nome, m, nivel);
case &quot;3&quot;: return new AtacanteDistancia(nome, m, nivel);
case &quot;4&quot;: return new Estrategista(nome, m, nivel);
case &quot;5&quot;: return new Robo(nome, m, nivel);

case &quot;6&quot;: return new Mago(nome, m, nivel);
default: return null;
}
}
}