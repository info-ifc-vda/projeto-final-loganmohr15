import java.util.*;

abstract class Combatente {
// encapsulamento: campos privados
private String nome;
private int vida;
private int ataque;
private int defesa;
private int nivel;
private Mitologia mitologia; // enum para tema (Grega, Nordica, Egipcia, Celta)
private List&lt;Item&gt; inventario = new ArrayList&lt;&gt;();

public Combatente(String nome, Mitologia m, int vida, int atk, int def, int nivel) {

this.nome = nome;
this.mitologia = m;
this.vida = vida;
this.ataque = atk;
this.defesa = def;
this.nivel = nivel;
}

// getters e setters controlados (encapsulamento)
public String getNome() { return nome; }
public int getVida() { return vida; }
public int getAtaque() { return ataque; }
public int getDefesa() { return defesa; }
public int getNivel() { return nivel; }
public Mitologia getMitologia() { return mitologia; }

public void setVida(int vida) { this.vida = Math.max(0, vida); }
public void setAtaque(int atk) { this.ataque = Math.max(0, atk); }
public void setDefesa(int def) { this.defesa = Math.max(0, def); }
public void setNivel(int nivel) { this.nivel = Math.max(1, nivel); }

public void adicionarItem(Item it) { if (it != null) inventario.add(it); }
public List&lt;Item&gt; getInventario() { return Collections.unmodifiableList(inventario); }

public boolean estaVivo() { return vida &gt; 0; }

// Métodos abstratos obrigatórios (abstração/polimorfismo)
public abstract void atacar(Combatente alvo, Random rnd);
public abstract int defender(int danoRecebido, Random rnd);
public abstract String descricao();

// método utilitário: aplicar dano direto
protected void aplicarDano(int dano) {
setVida(getVida() - dano);
}

// permitir uso de item (simples)
public void usarItem(int indice, Combatente alvo) {
if (indice &gt;= 0 &amp;&amp; indice &lt; inventario.size()) {
Item it = inventario.get(indice);
it.efeito(alvo);
System.out.println(&quot;&gt; &quot; + nome + &quot; usou &quot; + it.getNome() + &quot; em &quot; + alvo.getNome() + &quot;.&quot;);
inventario.remove(indice); // consumido
} else {
System.out.println(&quot;&gt; Item inválido.&quot;);
}
}

// lógica de evolução simples: aumentar stats ao subir de nivel
public void evoluir() {
setNivel(getNivel() + 1);
setAtaque((int)(getAtaque() * 1.1));
setDefesa((int)(getDefesa() * 1.1));
setVida(getVida() + 10);
}

@Override
public String toString() {
return String.format(&quot;%s [%s] (N%d) HP:%d ATK:%d DEF:%d&quot;, nome, mitologia, nivel, vida,
ataque, defesa);
}
}

/* Enum para mitologias */
enum Mitologia {
GREGA, NORDICA, EGIPCIA, CELTA;
}